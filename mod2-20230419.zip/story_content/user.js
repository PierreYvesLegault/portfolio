function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5ZmdgdxZQor":
        Script1();
        break;
  }
}

function Script1()
{
  window.top.location.replace("http://moodle-staging.oaciq.com/course/view.php?id=37");
}

